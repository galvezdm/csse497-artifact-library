/** Automatically generated file. DO NOT MODIFY */
package edu.rosehulman.artifacts;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}